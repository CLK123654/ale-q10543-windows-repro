这批材料用于Commerce Gateway发布前兼容性复核。openapi/base.json是当前生产合同，openapi/candidate.json是候选发布合同；compat_policy.json规定阻断类型、发布日期、弃用窗口、重点调用量阈值和需要观察的SDKoperation；sdk_usage.csv是本次客户端调用清单，客户端标识已经脱敏。

在压缩包根目录运行：

node output/check_api_compat.mjs .

脚本只使用Node.js标准库，覆盖生成output/reports中的五份报告。输入JSON、CSV和starter保持只读，处理期间不联网。
