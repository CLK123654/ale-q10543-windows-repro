#!/usr/bin/env node
import fs from "node:fs/promises";
import path from "node:path";

const root = process.argv[2] ?? ".";
const base = JSON.parse(await fs.readFile(path.join(root, "openapi/base.json"), "utf8"));
const candidate = JSON.parse(await fs.readFile(path.join(root, "openapi/candidate.json"), "utf8"));
const policy = JSON.parse(await fs.readFile(path.join(root, "compat_policy.json"), "utf8"));
const sdkCsv = await fs.readFile(path.join(root, "sdk_usage.csv"), "utf8");

// TODO: compare operations, request required fields, response enum values,
// deprecation periods and SDK usage, then write output/reports.
console.log({ baseVersion: base.info.version, candidateVersion: candidate.info.version, minDeprecationDays: policy.min_deprecation_days, sdkRows: sdkCsv.trim().split(/\r?\n/).length - 1 });
