#!/usr/bin/env node
import fs from "node:fs/promises";
import path from "node:path";

const root = path.resolve(process.argv[2] ?? ".");
const reportsDir = path.join(root, "output/reports");
const readJson = async (relative) => JSON.parse(await fs.readFile(path.join(root, relative), "utf8"));
const base = await readJson("openapi/base.json");
const candidate = await readJson("openapi/candidate.json");
const policy = await readJson("compat_policy.json");
const sdkCsvText = await fs.readFile(path.join(root, "sdk_usage.csv"), "utf8");

function parseCsv(source) {
  const rows = [];
  let row = [], cell = "", quoted = false;
  const text = source.replace(/^\uFEFF/, "");
  for (let index = 0; index < text.length; index += 1) {
    const character = text[index];
    if (quoted) {
      if (character === '"' && text[index + 1] === '"') { cell += '"'; index += 1; }
      else if (character === '"') quoted = false;
      else cell += character;
    } else if (character === '"') quoted = true;
    else if (character === ",") { row.push(cell); cell = ""; }
    else if (character === "\n") { row.push(cell.replace(/\r$/, "")); rows.push(row); row = []; cell = ""; }
    else cell += character;
  }
  if (quoted) throw new Error("sdk_usage.csv has an unterminated quoted field");
  if (cell || row.length) { row.push(cell.replace(/\r$/, "")); rows.push(row); }
  const nonEmpty = rows.filter((item) => item.some((value) => value !== ""));
  if (nonEmpty.length < 2) throw new Error("sdk_usage.csv must contain a header and data");
  const headers = nonEmpty[0];
  if (new Set(headers).size !== headers.length) throw new Error("sdk_usage.csv has duplicate headers");
  return nonEmpty.slice(1).map((values, rowIndex) => {
    if (values.length !== headers.length) throw new Error(`sdk_usage.csv row ${rowIndex + 2} has ${values.length} cells`);
    return Object.fromEntries(headers.map((header, columnIndex) => [header, values[columnIndex]]));
  });
}

const csvCell = (value) => {
  const text = String(value ?? "");
  return /[",\n\r]/.test(text) ? `"${text.replaceAll('"', '""')}"` : text;
};
const csvText = (headers, rows) => [headers.join(","), ...rows.map((row) => headers.map((header) => csvCell(row[header])).join(","))].join("\n") + "\n";
const httpMethods = new Set(["get", "put", "post", "delete", "options", "head", "patch", "trace"]);

function indexOperations(document, label) {
  if (!document || typeof document !== "object" || !document.paths || typeof document.paths !== "object") throw new Error(`${label} OpenAPI paths missing`);
  const index = new Map();
  for (const apiPath of Object.keys(document.paths).sort()) {
    for (const method of Object.keys(document.paths[apiPath]).map((value) => value.toLowerCase()).filter((value) => httpMethods.has(value)).sort()) {
      const operation = document.paths[apiPath][method];
      const operationId = operation?.operationId;
      if (typeof operationId !== "string" || !operationId) throw new Error(`${label} ${method.toUpperCase()} ${apiPath} has no operationId`);
      if (index.has(operationId)) throw new Error(`${label} has duplicate operationId ${operationId}`);
      index.set(operationId, { operationId, path: apiPath, method, operation });
    }
  }
  return index;
}

const requestSchema = (operation) => operation?.requestBody?.content?.["application/json"]?.schema ?? {};
function responseEnumIndex(operation) {
  const found = new Map();
  const visit = (schema, prefix) => {
    if (!schema || typeof schema !== "object") return;
    if (Array.isArray(schema.enum)) found.set(prefix.join("."), schema.enum.map(String));
    for (const [name, child] of Object.entries(schema.properties ?? {})) visit(child, [...prefix, name]);
    if (schema.items) visit(schema.items, [...prefix, "items"]);
  };
  for (const [status, response] of Object.entries(operation?.responses ?? {})) {
    const schema = response?.content?.["application/json"]?.schema;
    if (schema) visit(schema, [status]);
  }
  return found;
}

const baseIndex = indexOperations(base, "base");
const candidateIndex = indexOperations(candidate, "candidate");
const blockingTypes = new Set(policy.blocking_levels ?? []);
const allowedTypes = new Set(policy.allowed_non_breaking ?? []);
const rawChanges = [];
const newOperations = [];
const removedOperations = [];

for (const [operationId, baseEntry] of baseIndex) {
  const candidateEntry = candidateIndex.get(operationId);
  if (!candidateEntry) {
    removedOperations.push(baseEntry);
    rawChanges.push({ operation_id: operationId, path: baseEntry.path, method: baseEntry.method, change_type: "removed_operation", location: "paths" });
    continue;
  }
  const baseRequest = requestSchema(baseEntry.operation);
  const candidateRequest = requestSchema(candidateEntry.operation);
  const baseRequired = new Set(baseRequest.required ?? []);
  const candidateRequired = new Set(candidateRequest.required ?? []);
  for (const field of [...candidateRequired].filter((value) => !baseRequired.has(value)).sort()) {
    rawChanges.push({ operation_id: operationId, path: candidateEntry.path, method: candidateEntry.method, change_type: "new_required_request_field", location: `requestBody.required.${field}` });
  }
  const baseProperties = new Set(Object.keys(baseRequest.properties ?? {}));
  for (const field of Object.keys(candidateRequest.properties ?? {}).filter((value) => !baseProperties.has(value) && !candidateRequired.has(value)).sort()) {
    rawChanges.push({ operation_id: operationId, path: candidateEntry.path, method: candidateEntry.method, change_type: "new_optional_request_field", location: `requestBody.properties.${field}` });
  }
  const baseEnums = responseEnumIndex(baseEntry.operation);
  const candidateEnums = responseEnumIndex(candidateEntry.operation);
  for (const [enumPath, baseValues] of baseEnums) {
    const candidateValues = new Set(candidateEnums.get(enumPath) ?? []);
    for (const removedValue of baseValues.filter((value) => !candidateValues.has(value)).sort()) {
      rawChanges.push({ operation_id: operationId, path: candidateEntry.path, method: candidateEntry.method, change_type: "response_enum_value_removed", location: `responses.${enumPath}.${removedValue}` });
    }
  }
}
for (const [operationId, entry] of candidateIndex) if (!baseIndex.has(operationId)) newOperations.push(entry);

const precedence = new Map([
  ["new_required_request_field", 1], ["response_enum_value_removed", 2],
  ["removed_operation", 3], ["new_optional_request_field", 4],
]);
rawChanges.sort((left, right) => (precedence.get(left.change_type) ?? 99) - (precedence.get(right.change_type) ?? 99)
  || left.operation_id.localeCompare(right.operation_id) || left.location.localeCompare(right.location));
const breakingRows = rawChanges.map((change, index) => {
  const blocking = blockingTypes.has(change.change_type);
  if (!blocking && !allowedTypes.has(change.change_type)) throw new Error(`policy does not classify ${change.change_type}`);
  return { change_id: `BC-${String(index + 1).padStart(3, "0")}`, ...change, severity: blocking ? "blocker" : "notice", policy_result: blocking ? "fail" : "pass" };
});

const toUtcDay = (value) => {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value ?? "")) throw new Error(`invalid ISO date ${value}`);
  const milliseconds = Date.parse(`${value}T00:00:00Z`);
  if (!Number.isFinite(milliseconds)) throw new Error(`invalid ISO date ${value}`);
  return milliseconds;
};
const daysBetween = (start, end) => {
  const days = (toUtcDay(end) - toUtcDay(start)) / 86400000;
  if (!Number.isInteger(days) || days < 0) throw new Error(`invalid deprecation interval ${start}..${end}`);
  return days;
};
const minDeprecationDays = Number(policy.min_deprecation_days);
if (!Number.isInteger(minDeprecationDays) || minDeprecationDays < 0) throw new Error("min_deprecation_days must be a non-negative integer");
const deprecationRows = [];
for (const entry of candidateIndex.values()) {
  if (entry.operation?.deprecated !== true) continue;
  const deprecatedOn = entry.operation["x-deprecated-on"] ?? "";
  const sunsetOn = entry.operation["x-sunset-on"] ?? "";
  const complete = Boolean(deprecatedOn && sunsetOn);
  const windowDays = complete ? daysBetween(deprecatedOn, sunsetOn) : 0;
  deprecationRows.push({ operation_id: entry.operationId, path: entry.path, method: entry.method, deprecated_on: deprecatedOn, sunset_on: sunsetOn, window_days: windowDays, min_days: minDeprecationDays, policy_result: complete ? (windowDays >= minDeprecationDays ? "pass" : "fail") : "missing_notice" });
}
for (const entry of removedOperations) {
  const deprecatedOn = entry.operation?.["x-deprecated-on"] ?? "";
  const sunsetOn = entry.operation?.["x-sunset-on"] ?? policy.candidate_release_date ?? "";
  const complete = Boolean(deprecatedOn && sunsetOn);
  const windowDays = complete ? daysBetween(deprecatedOn, sunsetOn) : 0;
  deprecationRows.push({ operation_id: entry.operationId, path: entry.path, method: entry.method, deprecated_on: deprecatedOn, sunset_on: sunsetOn, window_days: windowDays, min_days: minDeprecationDays, policy_result: complete ? (windowDays >= minDeprecationDays ? "pass" : "fail") : "missing_notice" });
}

const sdkUsage = parseCsv(sdkCsvText).map((row) => {
  const weeklyCalls = Number(row.weekly_calls);
  if (!row.client_id || !row.operation_id || !row.owner || !Number.isInteger(weeklyCalls) || weeklyCalls < 0) throw new Error(`invalid SDK usage row for ${row.client_id || "unknown client"}`);
  return { ...row, weekly_calls: weeklyCalls };
});
const blockingByOperation = new Map();
const compatibleByOperation = new Map();
for (const change of breakingRows) {
  const target = change.severity === "blocker" ? blockingByOperation : compatibleByOperation;
  if (!target.has(change.operation_id)) target.set(change.operation_id, []);
  target.get(change.operation_id).push(change);
}
const deprecationByOperation = new Map(deprecationRows.map((row) => [row.operation_id, row]));
const watchOperations = policy.sdk_watch_operations ?? {};

function blockerAction(changes) {
  if (changes.some((change) => change.change_type === "removed_operation")) return `restore_operation_or_publish_${minDeprecationDays}_day_sunset`;
  const required = changes.filter((change) => change.change_type === "new_required_request_field").map((change) => change.location.split(".").at(-1));
  const removedEnums = changes.filter((change) => change.change_type === "response_enum_value_removed").map((change) => change.location.split(".").at(-1));
  if (required.length && removedEnums.length) return `hold_release_until_${required.join("_")}_optional_and_${removedEnums.join("_")}_enum_restored`;
  if (required.length) return `hold_release_until_${required.join("_")}_optional`;
  return `hold_release_until_${removedEnums.join("_")}_enum_restored`;
}

const sdkImpactRows = sdkUsage.map((usage) => {
  const blockers = blockingByOperation.get(usage.operation_id) ?? [];
  const deprecation = deprecationByOperation.get(usage.operation_id);
  let impact_level = "compatible";
  let required_action = "no_client_change";
  if (blockers.length) {
    impact_level = "blocker";
    required_action = blockerAction(blockers);
  } else if (deprecation && deprecation.policy_result !== "pass") {
    impact_level = "deprecation_violation";
    required_action = `extend_sunset_to_${minDeprecationDays}_days`;
  } else if (watchOperations[usage.operation_id]) {
    impact_level = "watch";
    required_action = String(watchOperations[usage.operation_id]);
  } else if (compatibleByOperation.has(usage.operation_id)) {
    impact_level = "compatible";
  }
  return { client_id: usage.client_id, sdk_version: usage.sdk_version, operation_id: usage.operation_id, owner: usage.owner, weekly_calls: usage.weekly_calls, impact_level, required_action };
});

const blockingRows = breakingRows.filter((row) => row.severity === "blocker");
const deprecationFailures = deprecationRows.filter((row) => row.policy_result !== "pass");
const requiredFixes = [];
for (const row of blockingRows) {
  if (row.change_type === "new_required_request_field") requiredFixes.push(`make request field ${row.location.split(".").at(-1)} optional or defer it to a new versioned operation`);
  else if (row.change_type === "response_enum_value_removed") {
    const parts = row.location.split(".");
    requiredFixes.push(`restore ${parts.at(-1)} enum value in ${row.operation_id} ${parts[1]} response`);
  } else if (row.change_type === "removed_operation") requiredFixes.push(`restore ${row.operation_id} or publish a compliant sunset schedule`);
}
for (const row of deprecationFailures.filter((item) => item.policy_result === "fail" && !removedOperations.some((removed) => removed.operationId === item.operation_id))) {
  requiredFixes.push(`extend ${row.operation_id} sunset date to at least ${minDeprecationDays} days`);
}
const safeChanges = [
  ...breakingRows.filter((row) => row.policy_result === "pass").map((row) => `new optional ${row.location.split(".").at(-1)}`),
  ...newOperations.sort((a, b) => a.operationId.localeCompare(b.operationId)).map((entry) => `new operation ${entry.operationId}`),
];
const highTrafficThreshold = Number(policy.high_traffic_weekly_calls ?? 0);
const advisory = {
  result: blockingRows.length || deprecationFailures.length ? "HOLD" : "READY",
  release_version: candidate?.info?.version ?? "",
  blocker_count: blockingRows.length,
  deprecation_policy_failures: deprecationFailures.length,
  high_traffic_clients: sdkImpactRows.filter((row) => row.impact_level === "blocker" && row.weekly_calls >= highTrafficThreshold).map((row) => row.client_id),
  required_fixes: requiredFixes,
  safe_changes: safeChanges,
};

const measures = {
  base_path_count: Object.keys(base.paths).length,
  candidate_path_count: Object.keys(candidate.paths).length,
  evaluated_operation_count: new Set([...baseIndex.keys(), ...candidateIndex.keys()]).size,
  breaking_change_rows: breakingRows.length,
  blocking_change_rows: blockingRows.length,
  deprecation_window_rows: deprecationRows.length,
  deprecation_policy_failures: deprecationFailures.length,
  sdk_client_rows: sdkImpactRows.length,
  blocker_client_rows: sdkImpactRows.filter((row) => row.impact_level === "blocker").length,
  release_blocker_count: advisory.blocker_count,
  safe_change_count: safeChanges.length,
  min_deprecation_days: minDeprecationDays,
  shortest_deprecation_window_days: Math.min(...deprecationRows.filter((row) => row.policy_result === "fail").map((row) => row.window_days), 0) || 0,
  inconsistency_count: 0,
};
const positiveFailedPeriods = deprecationRows.filter((row) => row.policy_result === "fail").map((row) => row.window_days);
measures.shortest_deprecation_window_days = positiveFailedPeriods.length ? Math.min(...positiveFailedPeriods) : 0;
const relationships = {
  removed_operations_are_blockers: removedOperations.every((entry) => blockingRows.some((row) => row.operation_id === entry.operationId && row.change_type === "removed_operation")),
  required_request_fields_are_blockers: rawChanges.filter((row) => row.change_type === "new_required_request_field").every((change) => blockingRows.some((row) => row.operation_id === change.operation_id && row.location === change.location)),
  response_enum_removal_is_blocker: rawChanges.filter((row) => row.change_type === "response_enum_value_removed").every((change) => blockingRows.some((row) => row.operation_id === change.operation_id && row.location === change.location)),
  optional_request_fields_are_not_blockers: breakingRows.filter((row) => row.change_type === "new_optional_request_field").every((row) => row.severity !== "blocker" && row.policy_result === "pass"),
  deprecation_window_checked_in_days: deprecationRows.every((row) => row.policy_result === "missing_notice" || row.window_days === daysBetween(row.deprecated_on, row.sunset_on)),
  sdk_usage_joined_by_operation_id: sdkImpactRows.length === sdkUsage.length && sdkImpactRows.every((row, index) => row.operation_id === sdkUsage[index].operation_id && row.client_id === sdkUsage[index].client_id),
  release_advisory_matches_reports: advisory.blocker_count === blockingRows.length && advisory.deprecation_policy_failures === deprecationFailures.length && advisory.result === (blockingRows.length || deprecationFailures.length ? "HOLD" : "READY"),
  report_counts_match_rows: measures.breaking_change_rows === breakingRows.length && measures.deprecation_window_rows === deprecationRows.length && measures.sdk_client_rows === sdkImpactRows.length,
};
measures.inconsistency_count = Object.values(relationships).filter((value) => !value).length;
const consistency = { result: measures.inconsistency_count === 0 ? "PASS" : "FAIL", measures, relationships };

await fs.mkdir(reportsDir, { recursive: true });
const outputs = new Map([
  ["breaking_changes.csv", csvText(["change_id", "operation_id", "path", "method", "change_type", "location", "severity", "policy_result"], breakingRows)],
  ["deprecation_periods.csv", csvText(["operation_id", "path", "method", "deprecated_on", "sunset_on", "window_days", "min_days", "policy_result"], deprecationRows)],
  ["sdk_impact_matrix.csv", csvText(["client_id", "sdk_version", "operation_id", "owner", "weekly_calls", "impact_level", "required_action"], sdkImpactRows)],
  ["release_advisory.json", JSON.stringify(advisory, null, 2) + "\n"],
  ["report_consistency.json", JSON.stringify(consistency, null, 2) + "\n"],
]);
for (const [filename, contents] of outputs) await fs.writeFile(path.join(reportsDir, `${filename}.tmp`), contents, "utf8");
for (const filename of outputs.keys()) await fs.rename(path.join(reportsDir, `${filename}.tmp`), path.join(reportsDir, filename));
console.log(JSON.stringify({ result: consistency.result, release: advisory.result, measures }, null, 2));
if (consistency.result !== "PASS") process.exitCode = 1;
